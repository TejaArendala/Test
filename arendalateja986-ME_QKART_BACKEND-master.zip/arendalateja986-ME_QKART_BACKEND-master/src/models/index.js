module.exports.User = require('./user.model').User
module.exports.Product = require("./product.model").Product;
module.exports.Cart =  require('./cart.model').Cart
